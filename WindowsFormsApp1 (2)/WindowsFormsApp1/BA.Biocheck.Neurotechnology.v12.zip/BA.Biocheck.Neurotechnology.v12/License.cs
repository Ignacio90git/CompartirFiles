﻿using System;
using Neurotec.Licensing;
using System.Collections.Generic;
using BA.Biocheck.Core.Common.Exceptions;
using Newtonsoft.Json;

namespace BA.Biocheck.Neurotechnology.v12
{
    public class License
    {
        private static List<string> componentes = new List<string>();
        public static void Release()
        {
            foreach (var item in componentes)
            {
                LogCmd.Log(string.Format("Liberando licenciamiento de neuro para .... {0} ", item));
                NLicense.ReleaseComponents(item);
                LogCmd.Log(string.Format("Liberado licenciamiento de neuro para .... {0} ", item));
            }

            componentes.Clear();
        }
        /// <summary>
        /// Obtiene la licencia de un componente
        /// </summary>
        /// <param name="component">Componente a obtener su licencia</param>
        public static void Get(string component)
        {
            try
            {
                if (componentes.Contains(component))
                {
                    return;
                }
                //remover licencias
                /*
                                if (component.Contains("Biometrics.FaceExtraction")) {
                                    component="";
                                }
                                if (component.Contains("Devices.Cameras"))
                                {
                                    component = "";
                                }
                                if (component.Contains("Biometrics.FaceSegmentsDetection"))
                                {
                                    component = "";
                                }/*
                               if (component.Contains("Biometrics.FingerMatching"))
                                {
                                    component = "";
                                }
                                if (component.Contains("Biometrics.FingerSegmentation"))
                                {
                                    component = "";
                                }*/

                LogCmd.Log(string.Format("Obteniendo licenciamiento de neuro para .... {0} ", component));

                const string Address = "/local";
                const int Port = 5000;
                foreach (string matchingComponent in component.Split(','))
                {
                    if (component != "")
                        if (!NLicense.ObtainComponents(Address, Port, matchingComponent))
                        {
                            LogCmd.LogError(string.Format("No se logro obtener la licencia [{0}]", matchingComponent));
                            throw new BiometricClassException(string.Format("[Excepcion personalizada] No se puedo obtener la licencia para el componente: {0}", component), BiometricExceptions.CantGetLicences);
                        }
                }
            }
            catch (Neurotec.NotActivatedException nex)
            {
                LogCmd.LogError(string.Format("[Excepcion NotActivatedException] No se puedo obtener la licencia para el componente: {0}. Mensaje:{1}. Excepcion:{2}.", component, nex.Message, JsonConvert.SerializeObject(nex)));
                throw new BiometricClassException(string.Format("[Excepcion NotActivatedException] No se puedo obtener la licencia para el componente: {0}. Mensaje:{1}. Excepcion:{2}.", component, nex.Message, JsonConvert.SerializeObject(nex)), BiometricExceptions.CantGetLicences);
            }
            catch (Exception ex)
            {
                LogCmd.LogError(string.Format("[Excepcion Generica] No se puedo obtener la licencia para el componente: {0}. Excepcion:{1}.", component, ex.ToString()));
                throw new BiometricClassException(string.Format("[Excepcion Generica] No se puedo obtener la licencia para el componente: {0}. Excepcion:{1}.", component, ex.ToString()), BiometricExceptions.CantGetLicences);
            }
            componentes.Add(component);
            LogCmd.Log(string.Format("Licenciamiento obtenido para {0}", component));
        }

        /// <summary>
        /// Obtiene el licenciamiento de todos los componentes de Neuro
        /// </summary>
        public static void Get()
        {
            Get("Biometrics.FingerExtraction");
            Get("Biometrics.PalmExtraction");
            Get("Biometrics.FaceExtraction");
            Get("Biometrics.IrisExtraction");
            Get("Biometrics.VoiceExtraction");
            Get("Biometrics.FingerMatchingFast");
            Get("Biometrics.FingerMatching");
            Get("Biometrics.PalmMatchingFast");
            Get("Biometrics.PalmMatching");
            Get("Biometrics.VoiceMatching");
            Get("Biometrics.FaceMatchingFast");
            Get("Biometrics.FaceMatching");
            Get("Biometrics.IrisMatchingFast");
            Get("Biometrics.IrisMatching");
            Get("Biometrics.FingerSegmentation");
            Get("Biometrics.PalmSegmentation");
            Get("Biometrics.FaceSegmentation");
            Get("Biometrics.IrisSegmentation");
            Get("Biometrics.VoiceSegmentation");
        }
    }
}
