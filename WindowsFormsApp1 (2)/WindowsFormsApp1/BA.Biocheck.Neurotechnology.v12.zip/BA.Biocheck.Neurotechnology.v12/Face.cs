﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Neurotec.Licensing;
using Neurotec.Devices;
using Neurotec.Biometrics;
using Neurotec.Biometrics.Client;
using Neurotec.Images;
using Neurotec.Images.Processing;
using Neurotec.IO;
using System.Threading;
using BA.Identitum3.Core.Common.Data;
using BA.Identitum3.Core.Common.EventHandlers;
using System.Drawing;
using BA.Identitum3.Core.Common.EventArguments;
using System.IO;
using System.ComponentModel;

namespace BA.Identitum3.Neurotechnology.v10
{
    public class Face
    {
        private Bitmap sampleImage;
        public event DisplayImageEventHandler showPreview;
        public event DisplayInstructionsEventHandler showInstructions;
        private NBiometricClient _biometricClient;
        public NDeviceManager deviceManager;
        public NSubject subject;
        public NFace face;
        public NCamera camera;
        public NBiometricStatus status;
        private DataFace _capturedFace = new DataFace();
        private bool _IsCompleted = false;
        static List<NLAttributes> monitorredAtributes = new List<NLAttributes>();


        public NImage Imagen;
        public NBuffer imgBuff;
        public byte[] ByteImg;
        public DataFace CapturedFace
        {
            get { return _capturedFace; }
        }
        public bool IsCompleted
        {
            get { return _IsCompleted; }
        }
        public class camArg : EventArgs
        {
            private string _origin;
            public string Origin
            {
                get { return _origin; }
            }
            public camArg(string pOrigin)
            {
                _origin = pOrigin;
            }
        }
        public NBiometricClient BiometricClient
        {
            get { return _biometricClient; }
            set { _biometricClient = value; }
        }

        /// <summary>
        /// Realiza la captura del rostro con la webcam.
        /// </summary>
        /// <returns> Datos del biométrico del rostro. </returns>
        ///
        public void CaptureFaceCam(bool IsLiveness)
        {
            DataFace FaceData = new DataFace();
            try
            {
            deviceManager = new NDeviceManager();
            deviceManager.DeviceTypes = NDeviceType.Camera;
            deviceManager.Initialize();
            camera = GetCameraForHub(deviceManager);
            _biometricClient = new NBiometricClient { UseDeviceManager = true };
            _biometricClient.FaceCaptureDevice = camera;

            if (_biometricClient.FaceCaptureDevice == null)
            {
                Console.WriteLine("No se detecto ningun dispositivo.");
                _capturedFace.Status = "No se detecto ningun dispositivo.";
                return;
            }

            deviceManager = _biometricClient.DeviceManager;
            subject = new NSubject();
            face = new NFace();
            {
                FaceData.Model = _biometricClient.FaceCaptureDevice.Model;
                FaceData.Serial = _biometricClient.FaceCaptureDevice.SerialNumber;
                FaceData.Manufacturer = "Genérico";
                Console.WriteLine("Capturing from {0}. Please turn camera to face.", _biometricClient.FaceCaptureDevice.DisplayName);

                // Define that the face source will be a stream
                face.CaptureOptions = NBiometricCaptureOptions.Stream;

                #region PRUEBA MARTYNAS
                if (IsLiveness)
                {
                    face.PropertyChanged += face_PropertyChanged;
                    face.Objects.CollectionChanged += Objects_CollectionChanged;
                    foreach (NLAttributes item in face.Objects.ToArray())
                    {
                        Console.WriteLine(item.ToString());
                        monitorredAtributes.Add(item);
                        item.PropertyChanged += attributes_PropertyChanged;
                    }
                }
                #endregion

                // Add NFace to NSubject
                subject.Faces.Add(face);
                if (IsLiveness)
                {
                    _biometricClient.FacesLivenessMode = NLivenessMode.Custom;
                    _biometricClient.FacesLivenessThreshold = 15;
                    _biometricClient.SetProperty("Faces.LivenessCustomSequence", "blink,turnLeft,turnRight,blink,delay");
                }
                _biometricClient.Timeout = new TimeSpan(0, 0, 30);

                EventHandler<EventArgs> FaceEvent = new EventHandler<EventArgs>(NCamera_Preview);
                camera.IsCapturingChanged += FaceEvent;
             
                    status = _biometricClient.Capture(subject);

                camera.IsCapturingChanged -= FaceEvent;
                if (status == NBiometricStatus.Ok)
                {
                    using (var image = subject.Faces[0].Image)
                    {
                        _capturedFace.FaceImage = getRecordFromImg(image, NImageFormat.Png);
                        Console.WriteLine("image saved successfully");
                        _capturedFace.Status = "Ok";
                    }
                }
                else
                {
                    _capturedFace.Status = status.ToString();
                }

            }
            camera.Dispose();
            face.Dispose();
            subject.Dispose();
            deviceManager.Dispose();
                }
                catch (Exception ex)
                {
                    FaceData.Status = ex.Message;
                    throw (ex);

                }
        }

        #region TEST MARTYNAS

        private void face_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if ("Image".Equals(e.PropertyName))
            {
                //image changed, redraw it
            }

        }

        private void Objects_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            if (e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Reset)
            {
                foreach (NLAttributes item in monitorredAtributes)
                {
                    item.PropertyChanged -= attributes_PropertyChanged;
                }
                monitorredAtributes.Clear();
            }
            else
            {
                if (e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Add)
                {
                    foreach (var item in e.NewItems)
                    {
                        NLAttributes attributes = (NLAttributes)item;
                        monitorredAtributes.Add(attributes);
                        attributes.PropertyChanged += attributes_PropertyChanged;
                    }
                }
                else
                {
                    if (e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Remove)
                    {
                        foreach (var item in e.OldItems)
                        {
                            NLAttributes attributes = (NLAttributes)item;
                            monitorredAtributes.Remove(attributes);
                            attributes.PropertyChanged -= attributes_PropertyChanged;
                        }
                    }
                }
            }
            //repaint();

        }

        private void attributes_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if ("LivenessAction".Equals(e.PropertyName))
            {
                Console.WriteLine("attributes_PropertyChanged: " + monitorredAtributes[0].LivenessAction);
                OnshowInstructions(new DisplayInstructionsEventArgs(monitorredAtributes[0].LivenessAction.ToString()));
            }
        }

        #endregion

        private void NCamera_Preview(object sender, EventArgs e)
        {

            try
            {
                NImage Imagen;
                NBuffer imgBuff;
                byte[] ByteImg;
                while (camera.IsCapturing)
                {
                    Thread.Sleep(50);
                    Imagen = camera.GetFrame();
                    if (Imagen != null)
                        imgBuff = Imagen.Save(NImageFormat.Bmp);
                    else
                        break;
                    ByteImg = imgBuff.ToArray();
                    imgBuff.Dispose();
                    Imagen.Dispose();
                    if (ByteImg != null)
                    {
                        OnshowPreview(new DisplayImageEventArgs(ByteImg));
                    }
                    ByteImg = null;
                }
            }
            catch (OutOfMemoryException ex)
            {
                Console.WriteLine("NCamera_Preview Exception: " + ex.Message);
                //camera.IsCapturingChanged -= new EventHandler<EventArgs>(NCamera_Preview);
                //throw (ex);
                _biometricClient.Reset();
                _biometricClient.Cancel();
               // CaptureFaceCam();
                
            }

        }

        public virtual void OnshowPreview(DisplayImageEventArgs e)
        {
            if (showPreview != null)
                showPreview(this, e);
        }

        public virtual void OnshowInstructions(DisplayInstructionsEventArgs e)
        {
            if (showInstructions != null)
                showInstructions(this, e);
        }

        private NCamera GetCameraForHub(NDeviceManager deviceManager)
        {
            try
            {
                NCamera currentScanner = null;

                if (deviceManager.Devices.Count > 0)
                {
                    Console.WriteLine(">>Found : " + deviceManager.Devices.Count + " devices.");
                    foreach (NDevice device in deviceManager.Devices)
                    {
                        Console.WriteLine("CAMERA: " + device.DisplayName);
                        if (device.DisplayName.IndexOf("Microsoft") != -1)
                        {
                            Console.WriteLine("SE ENCONTRÓ  Microsoft LifeCam Studio");
                            currentScanner = (NCamera)device;
                        }
                    }
                    if (currentScanner != null)
                    //    throw (new Exception("No device found."));
                        Console.WriteLine(">>Device to use ->" + currentScanner.DisplayName + "-" + currentScanner.Model);
                    //deviceManager.Dispose();

                    return currentScanner;
                }
                //deviceManager.Dispose();
                return null;
            }
            catch (Exception ex)
            {
                Console.WriteLine("!!Error on GetCameraForHub: " + ex.Message.ToString());

                throw;
            }
        }

        private byte[] getRecordFromImg(NImage fimage, NImageFormat format)
        {
            NBuffer imgBuff = fimage.Save(format);
            return imgBuff.ToArray();
        }



    }
}
