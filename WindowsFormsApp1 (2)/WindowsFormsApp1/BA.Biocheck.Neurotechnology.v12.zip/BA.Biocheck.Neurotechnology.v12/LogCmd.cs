﻿using System;
using BA.Biocheck.Core.Common.Util;


namespace BA.Biocheck.Neurotechnology.v12
{
    internal class LogCmd
    {
        internal static void Log(string message)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            BA.LogRegister.Log.Print(message);
            Console.ForegroundColor = ConsoleColor.White;
        }
        internal static void LogError(string message)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            BA.LogRegister.Log.Print(message);
            Console.ForegroundColor = ConsoleColor.White;
        }

    }
}